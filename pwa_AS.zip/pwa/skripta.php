<?php;

if(isset($_POST['title'])){
    $mainTitle = $_POST['title'];
}else{
    $mainTitle = "N/A";
}
if(isset($_POST['about'])){
    $about = $_POST['about'];
}
if(isset($_POST['content'])){
    $content = $_POST['content'];
}
if(isset($_POST['category'])){
    $category = $_POST['category'];
}
if(isset($_POST['archive'])){
    $archive=1;
}else{
    $archive=0;
}
   
if(isset($_FILES['insertImg'])){
    $fileName=$_FILES['insertImg']['name'];
    $fileTmp=$_FILES['insertImg']['tmp_name'];
    $uploadFolder="img/";
    move_uploaded_file($fileTmp, $uploadFolder.$fileName);
}


$query = "INSERT INTO vijesti (naslov, sazetak, tekst, slika, kategorija,
arhiva ) VALUES ('$mainTitle', '$about', '$content', '$fileName',
'$category', '$archive')";
$result = mysqli_query($dbc, $query) or die('Error querying databese.');
mysqli_close($dbc);

?>