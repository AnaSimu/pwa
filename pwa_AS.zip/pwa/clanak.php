<?php
include 'connect.php';
define('UPLPATH', 'img/');
$id= $_GET["id"];

$query = "SELECT * FROM vijesti WHERE id=$id";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result)) {
            $mainTitle=$row['naslov'];
            $category=$row['kategorija'];
            $about=$row['sazetak'];
            $content=$row['tekst'];
            $slika=$row['slika'];
            }

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="#Home">Home</a>
            <a href="#Beruf&Karriere">Beruf & Karriere</a>
            <a href="#Food">Food</a>
            <a href="#Administracija">Administracija</a>
            <a href="unos.html">Unos</a>
        </nav>
        <br>

        
        </header>
    <main>
        <section>
            <article class="fullwidth">
                <section class="main-information">
                    <h1 class="main-title"><?php echo $mainTitle; ?></h1>
                </section>
                <section class="image">
                    <img src="<?php echo  UPLPATH . $slika; ?>">
                </section>
                <section class="content">
                    <p class="about"><?php echo $about; ?></p>
                    <p class="main-content"><?php echo $content; ?></p>
                </section>
            </article>
        </section>
    </main>
    <footer>
            <br><br>
                <h1 class="sredina">
                    WELT
                </h1>
                Ana Šimunović, asimunovi@tvz.hr, 2022
        </footer>
</body>