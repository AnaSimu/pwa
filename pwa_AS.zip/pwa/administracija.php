<?php
session_start(); 
include 'connect.php';
define('UPLPATH', 'img/');
$uspjesnaPrijava = "";
if (isset($_POST['submit'])){ 
    $prijavaImeKorisnika = $_POST['username']; 
    $prijavaLozinkaKorisnika = $_POST['pass']; 
    $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?"; 
    $stmt = mysqli_stmt_init($dbc); 
    if (mysqli_stmt_prepare($stmt, $sql)) { 
        mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika); 
        mysqli_stmt_execute($stmt); 
        mysqli_stmt_store_result($stmt); 
    } 
        mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, $levelKorisnika); 
        mysqli_stmt_fetch($stmt); 
        if (password_verify($_POST['pass'], $lozinkaKorisnika) && mysqli_stmt_num_rows($stmt) > 0) {
            $uspjesnaPrijava = true;
            if($levelKorisnika == 1) {
            $admin = true;
            }
            else {
            $admin = false;
            }   
            $_SESSION['$username'] = $imeKorisnika;
            $_SESSION['$level'] = $levelKorisnika;
        } else {
        $uspjesnaPrijava = false;
    }
   
   }
   if(isset($_POST['delete'])){
    $id=$_POST['id'];
    $query = "DELETE FROM vijesti WHERE id=$id ";
    $result = mysqli_query($dbc, $query);
    }
    if(isset($_POST['update'])){
    $picture = $_FILES['pphoto']['name'];
    $title=$_POST['title'];
    $about=$_POST['about'];
    $content=$_POST['content'];
    $category=$_POST['category'];
    if(isset($_POST['archive'])){
     $archive=1;
    }else{
     $archive=0;
    }

    $target_dir = 'img/'.$picture;
    move_uploaded_file($_FILES["pphoto"]["tmp_name"], $target_dir);
    $id=$_POST['id'];
    $query = "UPDATE vijesti SET naslov='$title', sazetak='$about', tekst='$content', slika='$picture', kategorija='$category', arhiva='$archive' WHERE id=$id ";
    $result = mysqli_query($dbc, $query);
}
   ?>
   
   <!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="#Home">Home</a>
            <a href="#Beruf&Karriere">Beruf & Karriere</a>
            <a href="#Food">Food</a>
            <a href="#Administracija">Administracija</a>
            <a href="unos.html">Unos</a>
        </nav>
        <br>

        
        </header>
    <main>
    <?php
    if (($uspjesnaPrijava == true && $admin == true) || (isset($_SESSION['$username'])) && $_SESSION['$level'] == 1) {
    $query = "SELECT * FROM vijesti";
    $result = mysqli_query($dbc, $query);
    while($row = mysqli_fetch_array($result)) {
        echo '<form enctype="multipart/form-data" action="" method="POST">
            <div class="form-item">
                <label for="title">News title:</label>
                <div class="form-field">
                    <input type="text" name="title" class="form-field-text" value="'.$row['naslov'].'">
                </div>
            </div>

            <div class="form-item">
                <label for="about">Short summary (up to 100 characters):</label>
                <div class="form-field">
                    <textarea name="about" id="form-field-textual" cols="30" rows="10" class="form-field-textual">'.$row['sazetak'].'</textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="content">News content:</label>
                <div class="form-field">
                    <textarea name="content" id="form-field-textual" cols="30" rows="10" class="form-field-textual">'.$row['tekst'].'</textarea>
                </div>
            </div>

            <div class="form-item">
                <label for="pphoto">Image:</label>
                <div class="form-field">
                    <input type="file" class="input-text" id="pphoto" value="'.$row['slika'].'" name="pphoto"/> <br><img src="' . UPLPATH . $row['slika'] . '" width=100px>
                </div>
            </div>

            <div class="form-item">
                <label for="category">News category:</label>
                <div class="form-field" >
                    <select name="category" id="category" class="form-field-textual" value="'.$row['kategorija'].'">
                        <option value="Movies">Movies</option>
                        <option value="TV-shows">TV-shows</option>
                    </select>
                </div>
            </div>

            <div class="form-item">
                <label>Save to archive:
                <div class="form-field">';
                    if($row['arhiva'] == 0) {
                        echo '<input type="checkbox" name="archive" id="archive"/> Archive?';
                    } else {
                        echo '<input type="checkbox" name="archive" id="archive" checked/> Archive?';
                    }
                echo '</div>
                </label>
            </div>
        </div>
        <div class="form-item">
            <input type="hidden" name="id" class="form-field-textual" value="'.$row['id'].'">
            <button type="reset" value="cancel">Cancel</button>
            <button type="submit" name="update" value="Prihvati" id="true">Update</button>
            <button type="submit" name="delete" value="Izbriši" id="false">Delete</button>
  </div>
  </form><hr>';

 }

 } else if ($uspjesnaPrijava == true && $admin == false) {

 echo '<p class="msg">Hi ' . $imeKorisnika . '! You are logged in sucessfully!<br>To login from another account follow this link <a href="prijava.php">LOGIN PAGE</a></p>';
 } else if (isset($_SESSION['$username']) && $_SESSION['$level'] == 0) {
    echo '<p class="msg">Hi ' . $_SESSION['$username'] . '! You are logged in sucessfully!<br>To login from another account follow this link <a href="prijava.php">LOGIN PAGE</a></p>';
} else if ($uspjesnaPrijava == false) {
    echo '<form action="" method="POST">
            <div class="form-item"> 
                <span id="porukaUsername" class="error"></span> 
                <label for="content">Korisničko ime:</label>
                <div class="form-field">
                     <input type="text" name="username" id="username" class="form-field-text">
                </div> 
            </div> 

            <div class="form-item"> 
                <span id="porukaPass" class="error"></span> 
                <label for="pphoto">Lozinka: </label> 
                <div class="form-field">
                    <input type="password" name="pass" id="pass" class="form-field-text"> 
                </div> 
            </div> 

            <div class="form-item"> 
                <button type="submit" value="submit" id="submit" name="submit">Prijava</button>
            </div> 
        </form>';
        }
?>
   </main>
   <script type="text/javascript">
    document.getElementById("submit").onclick = function(event) {
        var slanjeForme = true;

        var poljeUsername = document.getElementById("username");
        var username = document.getElementById("username").value;
        if (username.length == 0) {
            slanjeForme = false;
            poljeUsername.style.border="1px dashed red";
            document.getElementById("porukaUsername").innerHTML="<br>Unesite korisničko ime!<br>";
         } else { poljeUsername.style.border="1px solid green";
            document.getElementById("porukaUsername").innerHTML="";
         }
         
        var poljePass = document.getElementById("pass");
        var pass = document.getElementById("pass").value; 
        if (pass.length == 0) { 
            slanjeForme = false; 
            document.getElementById("porukaPass").innerHTML="<br>Unesite lozinku!<br>";
            poljePass.style.border="1px dashed red"; 
        } else { poljePass.style.border="1px solid green"; 
            document.getElementById("porukaPass").innerHTML=""; 
        } if (slanjeForme != true) {
             event.preventDefault(); 
            }
        };
    </script>
    <footer>
            <br><br>
                <h1 class="sredina">
                    WELT
                </h1>
                Ana Šimunović, asimunovi@tvz.hr, 2022
        </footer>
</body>