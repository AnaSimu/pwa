<?php
include 'connect.php';

$msg="";
if(isset($_POST['ime']) && isset($_POST['prezime']) && isset($_POST['username']) && isset($_POST['pass'])){
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $username = $_POST['username'];
    $lozinka = $_POST['pass'];
    $hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);

    $razina = 0;
    $registriranKorisnik = '';

    $sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 's', $username);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
    } 
    if(mysqli_stmt_num_rows($stmt) > 0){
        $msg='Korisničko ime već postoji!';
    }else{
        $sql = "INSERT INTO korisnik (ime, prezime,korisnicko_ime, lozinka, razina)VALUES (?, ?, ?, ?, ?)";
        $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
        mysqli_stmt_bind_param($stmt, 'ssssd', $ime, $prezime, $username, $hashed_password, $razina);
        mysqli_stmt_execute($stmt);
        $registriranKorisnik = true;
     }
    } 
}
mysqli_close($dbc);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="#Home">Home</a>
            <a href="#Beruf&Karriere">Beruf & Karriere</a>
            <a href="#Food">Food</a>
            <a href="#Administracija">Administracija</a>
            <a href="unos.html">Unos</a>
        </nav>
        <br>

        
        </header>
    <main>
        <form enctype="multipart/form-data" action="" method="POST">
             <div class="form-item">
                <span id="porukaIme" class="error"></span>
                <label for="title">First name: </label>
                <div class="form-field"> 
                    <input type="text" name="ime" id="ime" class="form-field-text"> 
                </div>
             </div>

            <div class="form-item"> 
                <span id="porukaPrezime" class="error"></span>
                <label for="about">Last name: </label>
                <div class="form-field"> 
                    <input type="text" name="prezime" id="prezime" class="form-field-text"> 
                </div> 
            </div> 

            <div class="form-item"> 
                <span id="porukaUsername" class="error"></span> 
                <label for="content">Username:</label>
                <?php echo '<br><span class="error">'.$msg.'</span>'; ?>
                <div class="form-field">
                     <input type="text" name="username" id="username" class="form-field-text">
                </div> 
            </div> 

            <div class="form-item"> 
                <span id="porukaPass" class="error"></span> 
                <label for="pphoto">Password: </label> 
                <div class="form-field">
                    <input type="password" name="pass" id="pass" class="form-field-text"> 
                </div> 
            </div> 
            
            <div class="form-item"> 
                <span id="porukaPassRep" class="error"></span> 
                <label for="pphoto">Repeat password: </label> 
                <div class="form-field"> 
                    <input type="password" name="passRep" id="passRep" class="form-field-text"> 
                </div> 
            </div> 

            <div class="form-item"> 
                <button type="submit" value="submit" id="submit">Register</button>
            </div> 
        </form> 
    </main>
    <script type="text/javascript">
    document.getElementById("submit").onclick = function(event) {
        var slanjeForme = true;
        var poljeIme = document.getElementById("ime");
        var ime = document.getElementById("ime").value;
        if (ime.length == 0) {
            slanjeForme = false;
            poljeIme.style.border="1px dashed red";
            document.getElementById("porukaIme").innerHTML="<br>Enter first name!<br>";
         } else {
            poljeIme.style.border="1px solid green";
            document.getElementById("porukaIme").innerHTML="";
         } 

        var poljePrezime = document.getElementById("prezime");
        var prezime = document.getElementById("prezime").value;
        if (prezime.length == 0) { slanjeForme = false;
            poljePrezime.style.border="1px dashed red"; 
            document.getElementById("porukaPrezime").innerHTML="<br>Enter last name!<br>"; 
        } else {
            poljePrezime.style.border="1px solid green";
            document.getElementById("porukaPrezime").innerHTML="";
         }

        var poljeUsername = document.getElementById("username");
        var username = document.getElementById("username").value;
        if (username.length == 0) {
            slanjeForme = false;
            poljeUsername.style.border="1px dashed red";
            document.getElementById("porukaUsername").innerHTML="<br>Enter username!<br>";
         } else { poljeUsername.style.border="1px solid green";
            document.getElementById("porukaUsername").innerHTML="";
         }
         
        var poljePass = document.getElementById("pass");
        var pass = document.getElementById("pass").value; 
        var poljePassRep = document.getElementById("passRep"); 
        var passRep = document.getElementById("passRep").value; 
        if (pass.length == 0 || passRep.length == 0 || pass != passRep) { 
            slanjeForme = false; 
            poljePass.style.border="1px dashed red"; 
            poljePassRep.style.border="1px dashed red"; 
            document.getElementById("porukaPass").innerHTML="<br>Passwords are not matching!<br>"; 
            document.getElementById("porukaPassRep").innerHTML="<br>Passwords are not matching!<br>"; 
        } else { poljePass.style.border="1px solid green"; 
            poljePassRep.style.border="1px solid green"; 
            document.getElementById("porukaPass").innerHTML=""; 
            document.getElementById("porukaPassRep").innerHTML=""; 
        } if (slanjeForme != true) {
             event.preventDefault(); 
            }
        };
    </script>
     <footer>
            <br><br>
                <h1 class="sredina">
                    WELT
                </h1>
                Ana Šimunović, asimunovi@tvz.hr, 2022
        </footer>
</body>