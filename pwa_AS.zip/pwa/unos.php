<?php
include 'connect.php';

if(isset($_POST['title'])){
    $mainTitle = $_POST['title'];
}else{
    $mainTitle = "N/A";
}
if(isset($_POST['about'])){
    $about = $_POST['about'];
}
if(isset($_POST['content'])){
    $content = $_POST['content'];
}
if(isset($_POST['category'])){
    $category = $_POST['category'];
}
if(isset($_POST['archive'])){
    $archive=1;
}else{
    $archive=0;
}
   
if(isset($_FILES['insertImg'])){
    $fileName=$_FILES['insertImg']['name'];
    $fileTmp=$_FILES['insertImg']['tmp_name'];
    $uploadFolder="img/";
    move_uploaded_file($fileTmp, $uploadFolder.$fileName);
}


$query = "INSERT INTO vijesti (naslov, sazetak, tekst, slika, kategorija,
arhiva ) VALUES ('$mainTitle', '$about', '$content', '$fileName',
'$category', '$archive')";
$result = mysqli_query($dbc, $query) or die('Error querying databese.');
mysqli_close($dbc);

?>

<!DOCTYPE html>
<html>
    <!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="index.html">Home</a>
            <a href="index.html/#Beruf">Beruf & Karriere</a>
            <a href="index.html/#Food">Food</a>
            <a href="index.html/#Administracija">Administracija</a>
        </nav>







<form action="skripta.php" method="POST">
 <div class="form-item">
 <label for="title">Naslov vijesti</label>
 <div class="form-field">
 <input type="text" name="title" class="form-field-textual">
 </div>
 </div>
 <div class="form-item">
 <label for="about">Kratki sadržaj vijesti: (do 50
znakova)</label>
 <div class="form-field">
 <textarea name="about" id="" cols="30" rows="10" class="formfield-textual"></textarea>
 </div>
 </div>
 <div class="form-item">
 <label for="content">Sadržaj vijesti:</label>
 <div class="form-field">
 <textarea name="content" id="" cols="30" rows="10"
class="form-field-textual"></textarea>
 </div>
 </div>
 <div class="form-item">
 <label for="pphoto">Odabrite sliku: </label>
 <div class="form-field">
 <input type="file" accept="image/jpg,image/gif"
class="input-text" name="pphoto"/>
 </div>
 </div>
 <div class="form-item">
 <label for="category">Kategorija vijesti</label>
 <div class="form-field">
    <select name="category" id="" class="form-field-textual">
    <option value="sport">Sport</option>
    <option value="promet">Prometne vijesti</option>
    <option value="hrana">Hrana</option>
    <option value="glazba">Glazba</option>

    </select>
    </div>
    </div>
    <div class="form-item">
    <label>Objaviti na stranici?:
    <div class="form-field">
    <input type="checkbox" name="archive">
    </div>
    </label>
    </div>
    <div class="form-item">
    <button type="reset" value="Poništi">Poništi</button>
    <button type="submit" value="Prihvati">Prihvati</button>
    </div>
    </form>

    <footer>
        
    </footer>
    </html>