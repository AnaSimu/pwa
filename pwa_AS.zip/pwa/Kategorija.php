<?php
include 'connect.php';
define('UPLPATH', 'img/');
$kategorija= $_GET["kategorija"];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="#Home">Home</a>
            <a href="#Beruf&Karriere">Beruf & Karriere</a>
            <a href="#Food">Food</a>
            <a href="#Administracija">Administracija</a>
            <a href="unos.html">Unos</a>
        </nav>
        <br>

        
        </header> 
    <main>
        <section>
            <h1><?php echo $kategorija; ?></h1>
            <?php
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='$kategorija'";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result)) {
            echo '<article>';
            echo '<div class="slika">';
                echo '<img src="' . UPLPATH . $row['slika'] . '"';
            echo '</div>';
            echo '<div class="media_body">';
            echo '<h1 class="title">';
            echo '<a href="article.php?id='.$row['id'].'">';
            echo $row['naslov'];
            echo '</a></h1>';
            echo '</div>';
            echo '</article>';
        }?>
        </section>
    </main>
    <footer>
            <br><br>
                <h1 class="sredina">
                    WELT
                </h1>
                Ana Šimunović, asimunovi@tvz.hr, 2022
        </footer>
</body>