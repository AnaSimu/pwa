<?php
include 'connect.php';
define('UPLPATH', 'img/');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Home</title>
    <meta name="author" content="Ana Šimunović, 0246094646">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="style.css">
    <div class="page-wrapper"></div>
</head>

<body>
    <header>
        <h1>WELT</h1>
        <nav>
            <a href="#Home">Home</a>
            <a href="#Beruf&Karriere">Beruf & Karriere</a>
            <a href="#Food">Food</a>
            <a href="#Administracija">Administracija</a>
            <a href="unos.html">Unos</a>
        </nav>
        <br>

        
        </header>

        <section id="artikli">
            <h1 id="dobrodosli">Welcome to BBC</h1>
            <h2 id="datum"></h2>
        </section>
        <section id="artikli">
            <h3 id="news">News</h3>
            <br>
            <?php
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='news' LIMIT 3";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result))  {
              echo '<div col-4 row center>';
                echo '<article>';
              echo '<div class="movie_img">';
                  echo '<img src="' . UPLPATH . $row['slika'] . '"';
              echo '</div>';
              echo '<div class="media_body">';
              echo '<h1 class="title">';
              echo '<a href="article.php?id='.$row['id'].'">';
              echo $row['naslov'];
              echo '</a></h1>';
              echo '</div>';
              echo '</article>';
              echo '</div>';
          }
        ?>
        </section>
        <br>
        <section id="artikli">
            <h3 id="sport">Sport</h3>
            <br>
            <?php
            $query = "SELECT * FROM vijesti WHERE arhiva=0 AND kategorija='sport' LIMIT 3";
            $result = mysqli_query($dbc, $query);
            $i=0;
            while($row = mysqli_fetch_array($result)) {
            echo '<article>';
            echo '<div class="slika">';
                echo '<img src="' . UPLPATH . $row['slika'] . '"';
            echo '</div>';
            echo '<div class="media_body">';
            echo '<h4 class="title">';
            echo '<a href="article.php?id='.$row['id'].'">';
            echo $row['naslov'];
            echo '</a></h4>';
            echo '<p class="tekst">';
            echo '<a href="article.php?id='.$row['id'].'">';
            echo $row['sazetak'];
            echo '</div>';
            echo '</article>';
        }
        ?>
        </section>

        <footer>
            <br><br>
                <h1 class="sredina">
                    WELT
                </h1>
                Ana Šimunović, asimunovi@tvz.hr, 2022
        </footer> 
    </body>
    </html>